$(document).ready(function() {
    $('#telefone').mask('(00) 00000-0000');
});